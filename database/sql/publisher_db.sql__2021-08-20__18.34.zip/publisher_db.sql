-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 20, 2021 at 06:33 PM
-- Server version: 5.7.26
-- PHP Version: 7.4.2

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `publisher_db`
--
CREATE DATABASE IF NOT EXISTS `publisher_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `publisher_db`;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_authors`
--

DROP TABLE IF EXISTS `tbl_authors`;
CREATE TABLE `tbl_authors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('1','2','3','4') COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `priority` tinyint(4) DEFAULT '0',
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_authors`
--

REPLACE INTO `tbl_authors` (`id`, `slug`, `image_url`, `first_name`, `last_name`, `status`, `priority`, `created_by`, `updated_by`, `deleted_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'ut-et-odio-corporis-est-sit-amet-commodi', 'https://via.placeholder.com/640x480.png/0066cc?text=quod', 'Gisselle', 'Green', '3', 20, 8, 5, NULL, '2014-08-08 06:26:13', '2021-08-20 07:34:41', NULL),
(2, 'dolorum-et-itaque-vero-consequatur', 'https://via.placeholder.com/640x480.png/00ff11?text=placeat', 'Marilou', 'Eichmann', '1', 1, 4, 1, NULL, '2016-02-10 14:46:13', '2021-08-20 07:34:41', NULL),
(3, 'debitis-quia-est-assumenda-rerum', 'https://via.placeholder.com/640x480.png/009944?text=magnam', 'Dale', 'Ullrich', '3', 15, 5, 8, NULL, '1987-07-16 04:27:22', '2021-08-20 07:34:41', NULL),
(4, 'facilis-numquam-libero-at-autem', 'https://via.placeholder.com/640x480.png/00ffdd?text=in', 'Wade', 'Schiller', '1', 5, 8, 6, NULL, '1973-12-06 02:52:22', '2021-08-20 07:34:41', NULL),
(5, 'et-sint-labore-tempore-inventore-quis', 'https://via.placeholder.com/640x480.png/000000?text=maiores', 'Providenci', 'Lemke', '3', 4, 9, 8, NULL, '1982-04-14 21:41:12', '2021-08-20 07:34:41', NULL),
(6, 'molestias-et-omnis-inventore-et-aut-quisquam-dolorem', 'https://via.placeholder.com/640x480.png/00eeee?text=ad', 'Lamont', 'Deckow', '4', 13, 8, 4, NULL, '1979-05-27 07:27:00', '2021-08-20 07:34:41', NULL),
(7, 'ullam-ipsa-tempore-quo-doloribus-aut-vel-nesciunt', 'https://via.placeholder.com/640x480.png/001188?text=reprehenderit', 'Art', 'Moore', '1', 5, 7, 4, NULL, '2000-08-23 12:54:27', '2021-08-20 07:34:41', NULL),
(8, 'est-qui-soluta-voluptatem-nulla-laudantium-velit', 'https://via.placeholder.com/640x480.png/004466?text=autem', 'Kyle', 'Bradtke', '4', 2, 7, 6, NULL, '1989-01-01 06:28:45', '2021-08-20 08:42:14', NULL),
(9, 'accusantium-ab-dolorum-quis-tempora-ducimus-quae-labore', 'https://via.placeholder.com/640x480.png/0022cc?text=voluptatem', 'Elias', 'Rodriguez', '1', 6, 2, 5, NULL, '1973-08-15 00:45:53', '2021-08-20 07:34:41', NULL),
(10, 'distinctio-possimus-corporis-quia-totam-repellendus-officiis-sit-itaque', 'https://via.placeholder.com/640x480.png/0077ff?text=aspernatur', 'Corbin', 'Keebler', '4', 1, 5, 1, NULL, '2004-05-14 01:21:50', '2021-08-20 07:34:41', NULL),
(11, 'possimus-officia-eaque-non-aliquam-occaecati', 'https://via.placeholder.com/640x480.png/006666?text=qui', 'Tanya', 'Dicki', '4', 19, 8, 7, NULL, '2014-01-26 04:42:44', '2021-08-20 07:34:41', NULL),
(12, 'voluptates-quia-saepe-doloremque-quo', 'https://via.placeholder.com/640x480.png/00cc88?text=repellat', 'Mikel', 'Stewen', '1', 7, 2, 1, NULL, '2017-10-08 09:46:13', '2021-08-20 08:39:23', NULL),
(13, 'dolores-sit-et-rerum-dolores', 'https://via.placeholder.com/640x480.png/0099aa?text=minus', 'Ophelia', 'Frami', '3', 20, 4, 4, NULL, '2021-03-14 22:53:30', '2021-08-20 07:34:41', NULL),
(14, 'accusamus-rerum-id-deleniti-accusantium', 'https://via.placeholder.com/640x480.png/007711?text=est', 'Lyla', 'Dooley', '1', 15, 8, 2, NULL, '1979-08-04 07:59:15', '2021-08-20 07:34:41', NULL),
(15, 'dolores-voluptas-et-modi-veritatis', 'https://via.placeholder.com/640x480.png/00ccff?text=voluptatem', 'Hester', 'Labadie', '1', 10, 3, 4, NULL, '2012-08-23 13:12:41', '2021-08-20 07:34:41', NULL),
(16, 'debitis-sed-itaque-beatae-soluta-possimus-quod', 'https://via.placeholder.com/640x480.png/005599?text=repellat', 'Ahmed', 'Hauck', '1', 7, 8, 2, NULL, '1970-10-30 02:10:41', '2021-08-20 07:34:41', NULL),
(17, 'enim-repellat-excepturi-modi', 'https://via.placeholder.com/640x480.png/0033bb?text=adipisci', 'Raul', 'Turcotte', '1', 20, 6, 7, NULL, '1981-03-13 13:25:19', '2021-08-20 07:34:41', NULL),
(18, 'ut-exercitationem-ea-ut-minima-et', 'https://via.placeholder.com/640x480.png/00ffaa?text=itaque', 'Magdalena', 'Shanahan', '2', 15, 6, 10, NULL, '2003-06-18 05:15:13', '2021-08-20 07:34:41', NULL),
(19, 'sed-incidunt-quos-veritatis-est-praesentium-officia-nisi', 'https://via.placeholder.com/640x480.png/005511?text=consequatur', 'Keon', 'Doyle', '1', 4, 5, 2, NULL, '2014-07-03 16:45:15', '2021-08-20 07:34:41', NULL),
(20, 'sit-nulla-nihil-distinctio-possimus-molestiae-amet-voluptates', 'https://via.placeholder.com/640x480.png/0044ff?text=qui', 'Demond', 'Hudson', '2', 8, 6, 6, NULL, '1996-06-02 06:56:08', '2021-08-20 07:34:41', NULL),
(21, 'torn-hamilton', NULL, 'Torn', 'Hamilton', '1', 0, 1, NULL, NULL, '2021-08-20 08:37:50', '2021-08-20 08:37:50', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_books`
--

DROP TABLE IF EXISTS `tbl_books`;
CREATE TABLE `tbl_books` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `author_id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `price` double(8,2) NOT NULL,
  `status` enum('1','2','3','4') COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `priority` tinyint(4) DEFAULT '0',
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_books`
--

REPLACE INTO `tbl_books` (`id`, `author_id`, `slug`, `image_url`, `title`, `description`, `price`, `status`, `priority`, `created_by`, `updated_by`, `deleted_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 20, 'consectetur-culpa-minus-deleniti-odit-perferendis-porro', 'https://via.placeholder.com/640x480.png/002244?text=repellat', 'Dr.', 'Alice laughed so much at first, perhaps,\' said the Footman, \'and that for the hedgehogs; and in THAT direction,\' the Cat went on, taking first one side and up the fan and the poor animal\'s feelings.', 3.00, '3', 19, 10, 9, NULL, '2009-04-21 19:22:17', '2021-08-20 07:34:41', NULL),
(2, 11, 'quo-consequatur-laudantium-molestiae-expedita', 'https://via.placeholder.com/640x480.png/007755?text=et', 'Miss', 'Mouse replied rather crossly: \'of course you don\'t!\' the Hatter was the first sentence in her hands, wondering if anything would EVER happen in a tone of this was the fan and two or three of the.', 1.00, '3', 16, 6, 3, NULL, '2008-03-05 12:16:35', '2021-08-20 07:34:41', NULL),
(3, 9, 'voluptates-autem-sunt-et-sit-error-quaerat', 'https://via.placeholder.com/640x480.png/00ddff?text=explicabo', 'Dr.', 'Caterpillar. \'Not QUITE right, I\'m afraid,\' said Alice, who always took a minute or two to think about stopping herself before she had been of late much accustomed to usurpation and conquest. Edwin.', 6.00, '1', 14, 3, 7, NULL, '2003-04-10 01:13:03', '2021-08-20 07:34:41', NULL),
(4, 13, 'omnis-sint-et-doloremque', 'https://via.placeholder.com/640x480.png/00aabb?text=impedit', 'Mrs.', 'I am in the distance would take the place where it had gone. \'Well! I\'ve often seen a rabbit with either a waistcoat-pocket, or a worm. The question is, Who in the shade: however, the moment she.', 1.00, '3', 5, 2, 8, NULL, '1981-03-25 10:44:33', '2021-08-20 07:34:41', NULL),
(5, 18, 'veniam-non-omnis-ducimus-ea-dolorum-eius-error', 'https://via.placeholder.com/640x480.png/0077ee?text=illo', 'Dr.', 'However, she got up in great fear lest she should push the matter on, What would become of you? I gave her answer. \'They\'re done with blacking, I believe.\' \'Boots and shoes under the sea--\' (\'I.', 3.00, '2', 20, 9, 4, NULL, '2003-11-28 18:18:10', '2021-08-20 07:34:41', NULL),
(6, 18, 'doloribus-quisquam-eveniet-pariatur-impedit-tempore', 'https://via.placeholder.com/640x480.png/007766?text=deleniti', 'Dr.', 'The Mouse did not much surprised at this, that she was exactly one a-piece all round. (It was this last remark. \'Of course it is,\' said the Mock Turtle, suddenly dropping his voice; and the whole.', 3.00, '4', 8, 9, 4, 1, '1999-11-13 03:27:03', '2021-08-20 09:26:51', '2021-08-20 09:26:51'),
(7, 10, 'quam-aliquam-dolorem-autem-odio', 'https://via.placeholder.com/640x480.png/005500?text=consequatur', 'Prof.', 'White Rabbit blew three blasts on the table. \'Nothing can be clearer than THAT. Then again--\"BEFORE SHE HAD THIS FIT--\" you never tasted an egg!\' \'I HAVE tasted eggs, certainly,\' said Alice, \'and.', 2.00, '2', 3, 6, 5, NULL, '1991-07-22 03:23:36', '2021-08-20 07:34:41', NULL),
(8, 5, 'optio-exercitationem-alias-mollitia-quidem-aperiam-tempore-repudiandae', 'https://via.placeholder.com/640x480.png/00ffdd?text=ratione', 'Mr.', 'Dormouse into the roof bear?--Mind that loose slate--Oh, it\'s coming down! Heads below!\' (a loud crash)--\'Now, who did that?--It was Bill, the Lizard) could not possibly reach it: she could do to.', 9.00, '1', 8, 9, 3, NULL, '1984-11-14 08:46:37', '2021-08-20 09:25:26', NULL),
(9, 5, 'aliquid-nesciunt-perspiciatis-aliquid-culpa-suscipit', 'https://via.placeholder.com/640x480.png/003388?text=quia', 'Ms.', 'Gryphon. \'It\'s all his fancy, that: he hasn\'t got no business of MINE.\' The Queen had never heard of uglifying!\' it exclaimed. \'You know what to say \"HOW DOTH THE LITTLE BUSY BEE,\" but it puzzled.', 7.00, '4', 14, 6, 10, NULL, '1987-03-15 12:41:29', '2021-08-20 07:34:41', NULL),
(10, 7, 'itaque-voluptates-quia-et-non-corrupti-labore', 'https://via.placeholder.com/640x480.png/00dddd?text=sunt', 'Prof.', 'It looked good-natured, she thought: still it was too late to wish that! She went on in a hurry. \'No, I\'ll look first,\' she said, without opening its eyes, \'Of course, of course; just what I used to.', 3.00, '2', 12, 7, 7, NULL, '2005-03-05 18:17:12', '2021-08-20 07:34:41', NULL),
(11, 15, 'odit-repellendus-vel-itaque-maiores', 'https://via.placeholder.com/640x480.png/00aa00?text=autem', 'Prof.', 'Gryphon replied very politely, \'for I can\'t quite follow it as she had asked it aloud; and in another moment, splash! she was talking. Alice could hear the name \'W. RABBIT\' engraved upon it. She.', 8.00, '1', 15, 4, 8, NULL, '2019-02-28 16:09:31', '2021-08-20 07:34:41', NULL),
(12, 1, 'rerum-consequatur-tenetur-non-corporis', 'https://via.placeholder.com/640x480.png/005577?text=vero', 'Miss', 'Advice from a bottle marked \'poison,\' it is I hate cats and dogs.\' It was so full of soup. \'There\'s certainly too much frightened that she knew that were of the jurymen. \'It isn\'t a letter, written.', 0.00, '2', 1, 4, 10, NULL, '1980-03-08 02:46:00', '2021-08-20 07:34:41', NULL),
(13, 3, 'rerum-rerum-nam-ut-voluptatum-non-dolores-sequi', 'https://via.placeholder.com/640x480.png/00aa11?text=earum', 'Dr.', 'Pigeon. \'I can see you\'re trying to find her in the world! Oh, my dear paws! Oh my dear paws! Oh my fur and whiskers! She\'ll get me executed, as sure as ferrets are ferrets! Where CAN I have done.', 3.00, '2', 17, 2, 7, NULL, '1971-10-23 04:36:42', '2021-08-20 07:34:41', NULL),
(14, 19, 'vel-unde-nesciunt-libero-iste-corrupti', 'https://via.placeholder.com/640x480.png/006699?text=quaerat', 'Mrs.', 'King, and the baby with some surprise that the poor little thing sobbed again (or grunted, it was out of a tree. \'Did you say things are worse than ever,\' thought the whole party swam to the other.', 1.00, '2', 7, 3, 2, NULL, '2010-04-13 19:27:22', '2021-08-20 07:34:41', NULL),
(15, 17, 'maxime-unde-ut-pariatur-voluptatem-veritatis-laborum', 'https://via.placeholder.com/640x480.png/009944?text=quia', 'Dr.', 'Majesty,\' said the Gryphon. \'Well, I can\'t remember,\' said the Gryphon. \'They can\'t have anything to say, she simply bowed, and took the hookah out of sight, he said in a very poor speaker,\' said.', 6.00, '2', 16, 5, 4, NULL, '1979-03-06 15:06:05', '2021-08-20 07:34:41', NULL),
(16, 15, 'repudiandae-ut-quidem-esse-dignissimos-perspiciatis-cumque-exercitationem', 'https://via.placeholder.com/640x480.png/0088dd?text=voluptatem', 'Mr.', 'There was a very poor speaker,\' said the King, the Queen, stamping on the bank, with her head!\' Alice glanced rather anxiously at the corners: next the ten courtiers; these were ornamented all over.', 8.00, '4', 10, 5, 7, NULL, '1981-03-08 17:13:24', '2021-08-20 07:34:41', NULL),
(17, 2, 'perspiciatis-est-vitae-dolor-beatae-aut', 'https://via.placeholder.com/640x480.png/00bb33?text=magni', 'Mrs.', 'I used to it in time,\' said the Duchess: you\'d better ask HER about it.\' (The jury all brightened up again.) \'Please your Majesty,\' he began, \'for bringing these in: but I don\'t remember where.\'.', 1.00, '2', 9, 1, 1, NULL, '2010-10-11 09:42:11', '2021-08-20 07:34:41', NULL),
(18, 10, 'eligendi-optio-voluptas-et-et-adipisci-sint-iste', 'https://via.placeholder.com/640x480.png/0033dd?text=et', 'Dr.', 'YOU sing,\' said the Caterpillar. Alice folded her hands, and was just going to happen next. \'It\'s--it\'s a very respectful tone, but frowning and making quite a long time with great curiosity, and.', 2.00, '2', 10, 5, 5, NULL, '1972-01-15 10:43:18', '2021-08-20 07:34:41', NULL),
(19, 20, 'ipsum-quod-cupiditate-aut-dolor-velit', 'https://via.placeholder.com/640x480.png/002200?text=deserunt', 'Prof.', 'But there seemed to have lessons to learn! No, I\'ve made up my mind about it; and the choking of the bottle was a dispute going on between the executioner, the King, who had not got into the air.', 6.00, '2', 17, 5, 4, NULL, '1975-03-16 07:29:30', '2021-08-20 07:34:41', NULL),
(20, 7, 'odit-error-dolor-qui-porro-at', 'https://via.placeholder.com/640x480.png/00ee77?text=et', 'Prof.', 'Grief, they used to it!\' pleaded poor Alice began to cry again. \'You ought to have finished,\' said the King say in a deep voice, \'are done with blacking, I believe.\' \'Boots and shoes under the.', 2.00, '2', 3, 8, 5, NULL, '2021-03-06 14:18:02', '2021-08-20 07:34:41', NULL),
(21, 13, 'ducimus-ea-non-voluptatum', 'https://via.placeholder.com/640x480.png/00dd77?text=sit', 'Mrs.', 'As soon as there was silence for some way of expecting nothing but out-of-the-way things to happen, that it was certainly English. \'I don\'t know much,\' said Alice; \'living at the White Rabbit, \'and.', 3.00, '4', 3, 4, 5, NULL, '2014-02-14 15:38:55', '2021-08-20 07:34:41', NULL),
(22, 7, 'assumenda-temporibus-quo-corrupti-dolorem-sunt-tempore-similique', 'https://via.placeholder.com/640x480.png/008888?text=veniam', 'Ms.', 'I\'ve got to see what was on the trumpet, and then the different branches of Arithmetic--Ambition, Distraction, Uglification, and Derision.\' \'I never thought about it,\' said the White Rabbit, who was.', 2.00, '2', 8, 10, 10, NULL, '1977-12-03 16:29:18', '2021-08-20 07:34:41', NULL),
(23, 16, 'qui-sunt-perferendis-non-facilis-esse-saepe', 'https://via.placeholder.com/640x480.png/004466?text=aperiam', 'Prof.', 'Queen was close behind it was out of sight: then it watched the White Rabbit, \'and that\'s a fact.\' Alice did not wish to offend the Dormouse go on in a sulky tone, as it lasted.) \'Then the words.', 6.00, '2', 11, 2, 5, NULL, '1998-10-27 00:47:53', '2021-08-20 07:34:41', NULL),
(24, 4, 'consequatur-ut-corrupti-ea-beatae', 'https://via.placeholder.com/640x480.png/0088aa?text=et', 'Prof.', 'Yet you turned a back-somersault in at the Cat\'s head began fading away the moment how large she had not noticed before, and he checked himself suddenly: the others looked round also, and all must.', 1.00, '2', 16, 1, 5, NULL, '1976-10-11 11:44:11', '2021-08-20 07:34:41', NULL),
(25, 17, 'magnam-tenetur-aliquam-excepturi', 'https://via.placeholder.com/640x480.png/0011ff?text=facilis', 'Prof.', 'King had said that day. \'That PROVES his guilt,\' said the Cat went on, \'What\'s your name, child?\' \'My name is Alice, so please your Majesty,\' said the Caterpillar contemptuously. \'Who are YOU?\' said.', 1.00, '3', 11, 2, 10, NULL, '2014-07-26 13:51:49', '2021-08-20 07:34:41', NULL),
(26, 1, 'possimus-molestias-odio-beatae-consequatur-ducimus-non-ea-et', 'https://via.placeholder.com/640x480.png/000000?text=corporis', 'Mr.', 'Alice. One of the way of expecting nothing but the Dodo said, \'EVERYBODY has won, and all would change to dull reality--the grass would be four thousand miles down, I think--\' (for, you see, so many.', 7.00, '3', 18, 6, 6, NULL, '1972-07-30 01:25:04', '2021-08-20 07:34:41', NULL),
(27, 4, 'accusantium-doloribus-quis-minima-itaque-saepe-dolorem-est', 'https://via.placeholder.com/640x480.png/009933?text=sed', 'Mr.', 'The first thing she heard a little queer, won\'t you?\' \'Not a bit,\' said the Hatter; \'so I should like to drop the jar for fear of killing somebody, so managed to put everything upon Bill! I wouldn\'t.', 8.00, '3', 14, 9, 9, NULL, '2020-04-11 00:37:32', '2021-08-20 07:34:41', NULL),
(28, 5, 'consequatur-aperiam-rem-eos-aut', 'https://via.placeholder.com/640x480.png/004488?text=iusto', 'Dr.', 'Mock Turtle. \'Hold your tongue, Ma!\' said the last words out loud, and the Gryphon went on, \'\"--found it advisable to go near the door and found in it about four inches deep and reaching half down.', 3.00, '3', 14, 2, 4, NULL, '1989-02-07 17:07:00', '2021-08-20 07:34:41', NULL),
(29, 20, 'esse-libero-qui-sit-dignissimos-perspiciatis-ut-molestiae', 'https://via.placeholder.com/640x480.png/0011dd?text=consequatur', 'Dr.', 'I\'ll go round a deal too far off to trouble myself about you: you must manage the best thing to eat or drink something or other; but the Gryphon in an undertone.', 1.00, '4', 3, 10, 3, NULL, '1997-12-26 16:16:12', '2021-08-20 07:34:41', NULL),
(30, 17, 'consequatur-nam-odit-labore-architecto-pariatur-perspiciatis-atque', 'https://via.placeholder.com/640x480.png/003388?text=rem', 'Prof.', 'Alice, and her face like the look of things at all, as the Caterpillar called after her. \'I\'ve something important to say!\' This sounded promising, certainly: Alice turned and came flying down upon.', 1.00, '3', 20, 8, 4, NULL, '1974-04-16 15:57:52', '2021-08-20 07:34:41', NULL),
(31, 5, 'et-molestiae-blanditiis-aliquam', 'https://via.placeholder.com/640x480.png/00ff66?text=sunt', 'Dr.', 'This speech caused a remarkable sensation among the party. Some of the Rabbit\'s voice along--\'Catch him, you by the officers of the singers in the last time she found a little house in it a very.', 7.00, '2', 20, 3, 6, NULL, '1980-03-07 16:59:54', '2021-08-20 07:34:41', NULL),
(32, 1, 'minus-deserunt-eum-accusamus-accusantium-ducimus-omnis-eum-esse', 'https://via.placeholder.com/640x480.png/009933?text=est', 'Prof.', 'I\'m perfectly sure I have done that?\' she thought. \'But everything\'s curious today. I think it so VERY wide, but she could have told you that.\' \'If I\'d been the whiting,\' said Alice, \'because I\'m.', 7.00, '3', 13, 8, 9, NULL, '1991-09-17 04:32:59', '2021-08-20 07:34:41', NULL),
(33, 8, 'repudiandae-repellat-laudantium-incidunt-placeat-vel-reiciendis', 'https://via.placeholder.com/640x480.png/0022dd?text=quos', 'Mr.', 'Alice, seriously, \'I\'ll have nothing more to come, so she helped herself to about two feet high, and was beating her violently with its wings. \'Serpent!\' screamed the Queen. First came ten soldiers.', 2.00, '2', 12, 4, 9, NULL, '1972-06-30 16:15:24', '2021-08-20 07:34:41', NULL),
(34, 1, 'velit-iure-et-voluptatibus-delectus-consequatur-id-dolor', 'https://via.placeholder.com/640x480.png/004455?text=laborum', 'Prof.', 'Though they were trying to find it out, we should all have our heads cut off, you know. Come on!\' So they began solemnly dancing round and round Alice, every now and then a great many more than.', 9.00, '3', 20, 8, 7, NULL, '1993-06-18 22:53:29', '2021-08-20 07:34:41', NULL),
(35, 7, 'amet-cumque-maxime-adipisci-architecto-rerum-nam-nihil-facilis', 'https://via.placeholder.com/640x480.png/008844?text=dolorem', 'Dr.', 'She soon got it out loud. \'Thinking again?\' the Duchess to play croquet.\' The Frog-Footman repeated, in the book,\' said the Gryphon. \'Well, I shan\'t go, at any rate: go and live in that soup!\' Alice.', 0.00, '2', 14, 5, 8, NULL, '2011-01-11 07:56:22', '2021-08-20 07:34:41', NULL),
(36, 7, 'aliquam-error-in-expedita-ut-quia-iste', 'https://via.placeholder.com/640x480.png/006655?text=perferendis', 'Mrs.', 'Yet you turned a corner, \'Oh my ears and the White Rabbit, \'and that\'s a fact.\' Alice did not like to see that queer little toss of her voice, and the poor child, \'for I never understood what it.', 7.00, '3', 16, 9, 3, NULL, '2003-11-10 04:19:40', '2021-08-20 07:34:41', NULL),
(37, 8, 'consequuntur-reprehenderit-maxime-fugiat-veritatis', 'https://via.placeholder.com/640x480.png/008899?text=eum', 'Prof.', 'The Duchess took her choice, and was just possible it had no pictures or conversations in it, and found in it a minute or two, and the choking of the garden, called out \'The Queen! The Queen!\' and.', 1.00, '1', 16, 1, 1, NULL, '1974-09-13 15:51:59', '2021-08-20 07:34:41', NULL),
(38, 1, 'consequatur-accusamus-neque-in-et', 'https://via.placeholder.com/640x480.png/008844?text=ratione', 'Mr.', 'Lizard in head downwards, and the words don\'t FIT you,\' said Alice, \'we learned French and music.\' \'And washing?\' said the Caterpillar. Alice thought she might as well wait, as she wandered about in.', 8.00, '4', 15, 10, 3, NULL, '1999-06-17 22:48:23', '2021-08-20 07:34:41', NULL),
(39, 7, 'perferendis-exercitationem-delectus-dicta-autem', 'https://via.placeholder.com/640x480.png/00aa66?text=vel', 'Mrs.', 'King said to herself, \'the way all the while, and fighting for the end of the Gryphon, \'she wants for to know what \"it\" means.\' \'I know SOMETHING interesting is sure to do it.\' (And, as you liked.\'.', 0.00, '3', 5, 10, 4, NULL, '1976-05-16 13:41:02', '2021-08-20 07:34:41', NULL),
(40, 13, 'repellat-ipsum-aut-optio-voluptas-quibusdam', 'https://via.placeholder.com/640x480.png/00eeff?text=sit', 'Mr.', 'WOULD put their heads down! I am so VERY much out of his great wig.\' The judge, by the White Rabbit; \'in fact, there\'s nothing written on the bank--the birds with draggled feathers, the animals with.', 7.00, '2', 14, 4, 9, NULL, '2021-02-22 13:18:11', '2021-08-20 07:34:41', NULL),
(41, 12, 'tenetur-nobis-placeat-voluptates-minima-in-natus-officiis', 'https://via.placeholder.com/640x480.png/0099bb?text=assumenda', 'Ms.', 'Gryphon, sighing in his turn; and both creatures hid their faces in their paws. \'And how did you call him Tortoise, if he had taken his watch out of THIS!\' (Sounds of more broken glass.) \'Now tell.', 6.00, '4', 18, 9, 6, NULL, '1981-07-30 04:38:41', '2021-08-20 07:34:41', NULL),
(42, 5, 'non-voluptatibus-quis-laborum-voluptatem-cupiditate-officiis-quia', 'https://via.placeholder.com/640x480.png/00ee22?text=id', 'Mr.', 'Alice did not wish to offend the Dormouse indignantly. However, he consented to go among mad people,\' Alice remarked. \'Oh, you can\'t help that,\' said the Cat, and vanished again. Alice waited.', 2.00, '1', 4, 8, 9, NULL, '2013-01-09 21:08:30', '2021-08-20 07:34:41', NULL),
(43, 20, 'incidunt-in-explicabo-iusto-quas-earum-eligendi-quis-aliquam', 'https://via.placeholder.com/640x480.png/004400?text=autem', 'Miss', 'I should frighten them out of a tree. \'Did you speak?\' \'Not I!\' said the Dodo, pointing to the heads of the room. The cook threw a frying-pan after her as hard as she fell very slowly, for she was.', 4.00, '3', 14, 3, 9, NULL, '2002-10-05 15:23:32', '2021-08-20 07:34:41', NULL),
(44, 1, 'voluptatem-laudantium-voluptates-ullam-architecto-eius-corporis-ut-laboriosam', 'https://via.placeholder.com/640x480.png/001122?text=est', 'Dr.', 'King. The White Rabbit hurried by--the frightened Mouse splashed his way through the glass, and she went on, very much at this, but at last she spread out her hand in hand, in couples: they were.', 6.00, '2', 7, 5, 3, NULL, '2017-01-02 13:32:03', '2021-08-20 07:34:41', NULL),
(45, 12, 'hic-qui-natus-quia-officiis', 'https://via.placeholder.com/640x480.png/001199?text=ut', 'Dr.', 'Father William,\' the young Crab, a little shriek, and went on all the right house, because the Duchess said in a piteous tone. And she tried to look down and saying \"Come up again, dear!\" I shall.', 7.00, '4', 10, 2, 9, NULL, '1980-09-27 01:47:57', '2021-08-20 07:34:41', NULL),
(46, 19, 'a-quis-recusandae-sint-corrupti', 'https://via.placeholder.com/640x480.png/00ee11?text=corrupti', 'Dr.', 'She went on in a great hurry. An enormous puppy was looking at the March Hare went on. \'Or would you tell me,\' said Alice, who felt very curious sensation, which puzzled her too much, so she began.', 0.00, '4', 5, 2, 6, NULL, '2003-12-09 01:39:14', '2021-08-20 07:34:41', NULL),
(47, 8, 'vel-nobis-eius-tenetur-perspiciatis-aut-et', 'https://via.placeholder.com/640x480.png/0077ee?text=doloribus', 'Prof.', 'I dare say there may be ONE.\' \'One, indeed!\' said the Hatter. \'He won\'t stand beating. Now, if you only kept on puzzling about it while the Mock Turtle is.\' \'It\'s the stupidest tea-party I ever was.', 4.00, '1', 11, 7, 9, NULL, '2014-02-10 01:14:54', '2021-08-20 07:34:41', NULL),
(48, 15, 'dolores-eveniet-magnam-blanditiis-omnis', 'https://via.placeholder.com/640x480.png/00bb88?text=suscipit', 'Prof.', 'Majesty,\' the Hatter hurriedly left the court, arm-in-arm with the lobsters, out to be beheaded!\' said Alice, seriously, \'I\'ll have nothing more to do it?\' \'In my youth,\' said the Gryphon: and Alice.', 8.00, '3', 14, 2, 1, NULL, '1991-08-14 20:01:13', '2021-08-20 07:34:41', NULL),
(49, 10, 'consectetur-vel-quae-voluptatem-distinctio-et-illum', 'https://via.placeholder.com/640x480.png/006688?text=dolor', 'Ms.', 'Alice indignantly, and she went back to the Duchess: \'what a clear way you have of putting things!\' \'It\'s a pun!\' the King had said that day. \'That PROVES his guilt,\' said the Mouse was speaking.', 2.00, '3', 7, 3, 5, NULL, '1981-06-21 11:12:57', '2021-08-20 07:34:41', NULL),
(50, 5, 'deleniti-nam-neque-rerum-quisquam-dolor', 'https://via.placeholder.com/640x480.png/007755?text=odio', 'Prof.', 'However, the Multiplication Table doesn\'t signify: let\'s try the thing Mock Turtle said: \'advance twice, set to work, and very angrily. \'A knot!\' said Alice, a little scream, half of them--and it.', 9.00, '4', 12, 2, 4, NULL, '2001-04-13 16:28:23', '2021-08-20 07:34:41', NULL),
(51, 10, 'ullam-nihil-eum-voluptatem-a', 'https://via.placeholder.com/640x480.png/008800?text=repellendus', 'Prof.', 'Mouse, getting up and throw us, with the end of half an hour or so, and were resting in the direction in which the wretched Hatter trembled so, that he had a wink of sleep these three weeks!\' \'I\'m.', 1.00, '2', 13, 3, 9, NULL, '1997-12-28 07:07:27', '2021-08-20 07:34:41', NULL),
(52, 7, 'consequuntur-ut-aut-quos-laboriosam', 'https://via.placeholder.com/640x480.png/0077bb?text=qui', 'Dr.', 'It was so much frightened that she still held the pieces of mushroom in her life, and had just succeeded in bringing herself down to them, they set to work shaking him and punching him in the other.', 4.00, '4', 14, 4, 9, NULL, '1981-09-23 03:01:48', '2021-08-20 07:34:41', NULL),
(53, 6, 'consequatur-est-nostrum-iste-dolores', 'https://via.placeholder.com/640x480.png/007744?text=velit', 'Ms.', 'Mock Turtle. \'Certainly not!\' said Alice loudly. \'The idea of having nothing to do: once or twice she had peeped into the garden, and marked, with one finger; and the Queen\'s absence, and were quite.', 1.00, '2', 15, 5, 4, NULL, '2012-08-13 22:59:53', '2021-08-20 07:34:41', NULL),
(54, 15, 'officiis-dolorem-dicta-deserunt', 'https://via.placeholder.com/640x480.png/007766?text=nihil', 'Mrs.', 'Alice did not dare to disobey, though she looked at it again: but he could think of any that do,\' Alice said nothing; she had been (Before she had got its neck nicely straightened out, and was.', 8.00, '3', 9, 9, 2, NULL, '2016-06-27 15:06:45', '2021-08-20 07:34:41', NULL),
(55, 17, 'consectetur-reiciendis-praesentium-pariatur-cupiditate-dolores-repellat-mollitia', 'https://via.placeholder.com/640x480.png/00ccff?text=maxime', 'Mr.', 'ARE you doing out here? Run home this moment, I tell you!\' said Alice. \'Call it what you would seem to put down yet, before the trial\'s over!\' thought Alice. One of the Queen said to live. \'I\'ve.', 7.00, '2', 5, 10, 10, NULL, '1995-05-27 22:48:56', '2021-08-20 07:34:41', NULL),
(56, 10, 'a-dolores-beatae-ipsa-commodi-voluptas-et-qui', 'https://via.placeholder.com/640x480.png/001111?text=tenetur', 'Mr.', 'THAT direction,\' waving the other players, and shouting \'Off with his head!\' or \'Off with their heads!\' and the baby--the fire-irons came first; then followed a shower of little cartwheels, and the.', 4.00, '3', 18, 6, 2, NULL, '2009-05-17 06:11:12', '2021-08-20 07:34:41', NULL),
(57, 20, 'atque-itaque-omnis-omnis-repellendus-error', 'https://via.placeholder.com/640x480.png/007722?text=minima', 'Mrs.', 'Alice. \'Call it what you like,\' said the King, the Queen, but she remembered having seen in her brother\'s Latin Grammar, \'A mouse--of a mouse--to a mouse--a mouse--O mouse!\') The Mouse did not get.', 8.00, '3', 18, 3, 4, NULL, '1985-02-15 12:54:58', '2021-08-20 07:34:41', NULL),
(58, 4, 'rerum-sed-eveniet-id-minima-aut-quo', 'https://via.placeholder.com/640x480.png/00bb66?text=et', 'Dr.', 'I don\'t know,\' he went on in the newspapers, at the bottom of the hall: in fact she was coming back to the Mock Turtle. \'She can\'t explain it,\' said the Pigeon. \'I\'m NOT a serpent, I tell you!\' But.', 0.00, '4', 3, 8, 7, NULL, '1982-12-06 22:09:39', '2021-08-20 07:34:41', NULL),
(59, 18, 'modi-sequi-aliquam-nisi-ut-veritatis-et-explicabo', 'https://via.placeholder.com/640x480.png/00ee88?text=cupiditate', 'Mr.', 'Indeed, she had not gone far before they saw Alice coming. \'There\'s PLENTY of room!\' said Alice very humbly: \'you had got burnt, and eaten up by two guinea-pigs, who were lying on the Duchess\'s.', 9.00, '2', 10, 5, 1, NULL, '1987-04-08 19:38:46', '2021-08-20 07:34:41', NULL),
(60, 16, 'omnis-qui-ut-rerum', 'https://via.placeholder.com/640x480.png/00ccdd?text=velit', 'Prof.', 'And yet I don\'t know,\' he went on in a moment. \'Let\'s go on for some time with the lobsters to the jury. They were indeed a queer-looking party that assembled on the floor, and a long breath, and.', 0.00, '3', 4, 9, 10, NULL, '1987-04-16 09:08:55', '2021-08-20 07:34:41', NULL),
(61, 7, '', NULL, 'Orage Girl', 'Grief, they used to it!\' pleaded poor Alice began to cry again. \'You ought to have finished,\' said the King say in a deep voice, \'are done with blacking, I believe.\' \'Boots and shoes under the.', 125.00, '1', 0, 1, NULL, NULL, '2021-08-20 09:24:21', '2021-08-20 09:24:21', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_failed_jobs`
--

DROP TABLE IF EXISTS `tbl_failed_jobs`;
CREATE TABLE `tbl_failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_migrations`
--

DROP TABLE IF EXISTS `tbl_migrations`;
CREATE TABLE `tbl_migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_migrations`
--

REPLACE INTO `tbl_migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(4, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(5, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(6, '2016_06_01_000004_create_oauth_clients_table', 1),
(7, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(8, '2019_08_19_000000_create_failed_jobs_table', 1),
(9, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(10, '2021_08_20_102215_add_some_fields_to_users_table', 1),
(11, '2021_08_20_102316_create_authors_table', 1),
(12, '2021_08_20_102327_create_books_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_oauth_access_tokens`
--

DROP TABLE IF EXISTS `tbl_oauth_access_tokens`;
CREATE TABLE `tbl_oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_oauth_access_tokens`
--

REPLACE INTO `tbl_oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('3f171dfb2d018b9793fb4aed03710266fb6305a9d0abd746562665f49118cadbb4e143440e1e8f5a', 1, 2, NULL, '[]', 0, '2021-08-20 07:36:54', '2021-08-20 07:36:54', '2022-08-20 12:06:54'),
('acc44bd682bf795c0ddd905bf1f1262d2dbc2c3af05f54bb0a2be5690fbfca094c26657f3580b3ea', 2, 2, NULL, '[]', 0, '2021-08-20 07:37:48', '2021-08-20 07:37:48', '2022-08-20 12:07:48');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_oauth_auth_codes`
--

DROP TABLE IF EXISTS `tbl_oauth_auth_codes`;
CREATE TABLE `tbl_oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_oauth_clients`
--

DROP TABLE IF EXISTS `tbl_oauth_clients`;
CREATE TABLE `tbl_oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_oauth_clients`
--

REPLACE INTO `tbl_oauth_clients` (`id`, `user_id`, `name`, `secret`, `provider`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'YPbkvC39wT6C4J3tt6hjzXUDHSQxrxo4bdhbZ8bh', NULL, 'http://localhost', 1, 0, 0, '2021-08-20 07:25:20', '2021-08-20 07:25:20'),
(2, NULL, 'Laravel Password Grant Client', 'g4BwrEMQ0nflYqI2Fjnv3C7cV522XcPsOgJvHyWv', 'users', 'http://localhost', 0, 1, 0, '2021-08-20 07:25:20', '2021-08-20 07:25:20');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_oauth_personal_access_clients`
--

DROP TABLE IF EXISTS `tbl_oauth_personal_access_clients`;
CREATE TABLE `tbl_oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_oauth_personal_access_clients`
--

REPLACE INTO `tbl_oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2021-08-20 07:25:20', '2021-08-20 07:25:20');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `tbl_oauth_refresh_tokens`;
CREATE TABLE `tbl_oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_oauth_refresh_tokens`
--

REPLACE INTO `tbl_oauth_refresh_tokens` (`id`, `access_token_id`, `revoked`, `expires_at`) VALUES
('5ec75765f4afff24d64ab88e5561281f352967e6e47a8cb031fa9b99ad2ff5600f83eda61dfc07ab', '3f171dfb2d018b9793fb4aed03710266fb6305a9d0abd746562665f49118cadbb4e143440e1e8f5a', 0, '2022-08-20 12:06:54'),
('61375c10312c7b860dcfe3da20796ee8ed7023edd94d4f00282dbdbdd3c4e3e094fc603e17596f08', 'acc44bd682bf795c0ddd905bf1f1262d2dbc2c3af05f54bb0a2be5690fbfca094c26657f3580b3ea', 0, '2022-08-20 12:07:48');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_password_resets`
--

DROP TABLE IF EXISTS `tbl_password_resets`;
CREATE TABLE `tbl_password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_personal_access_tokens`
--

DROP TABLE IF EXISTS `tbl_personal_access_tokens`;
CREATE TABLE `tbl_personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

DROP TABLE IF EXISTS `tbl_users`;
CREATE TABLE `tbl_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT '1',
  `is_publish_allowed` tinyint(1) DEFAULT '1',
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_users`
--

REPLACE INTO `tbl_users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `is_admin`, `is_publish_allowed`, `created_by`, `updated_by`, `deleted_by`, `deleted_at`) VALUES
(1, 'Will Dzama', 'will.dzama@gmail.com', '2021-08-20 07:34:40', '$2y$10$/lU0mZZF40TCs0hAYgsxxOjtQq7tOzK30q.6q0qk3tcAC.BcNKvaK', 'HsjYGHepUL', '2021-08-20 07:34:40', '2021-08-20 07:34:40', 1, 1, NULL, NULL, NULL, NULL),
(2, 'Darth Vader', 'vader@gmail.com', '2021-08-20 07:34:40', '$2y$10$pKsWnBLcI9HXy1fJCULudOk6APCG.KVfaryiYF3woBqRLGIHBFs6G', 'EBOG1eGcPn', '2021-08-20 07:34:40', '2021-08-20 07:34:40', 0, 0, NULL, NULL, NULL, NULL),
(3, 'Beau Sauer', 'hill.murl@example.com', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Fu8geXiycx', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 0, 0, NULL, NULL, NULL, NULL),
(4, 'Luella Rutherford', 'lauryn.kerluke@example.net', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '1RMBSzIR9N', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 1, 0, NULL, NULL, NULL, NULL),
(5, 'Miss Madonna Wehner V', 'king.herman@example.net', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '8sHTs668Ql', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 1, 0, NULL, NULL, NULL, NULL),
(6, 'Danny Fay', 'dortha.carroll@example.com', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '3dERLcAohu', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 1, 1, NULL, NULL, NULL, NULL),
(7, 'Ivy McKenzie', 'lavern.osinski@example.org', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'l8h8PElDEt', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 0, 1, NULL, NULL, NULL, NULL),
(8, 'Mrs. Kristina Wiza III', 'elva78@example.org', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'xFRkPreuHe', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 1, 1, NULL, NULL, NULL, NULL),
(9, 'Deontae Satterfield', 'jlynch@example.net', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'D8SDxnn3KT', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 0, 0, NULL, NULL, NULL, NULL),
(10, 'Dr. Martin Schuster V', 'haley.marcos@example.net', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Rzy5mhskHa', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 0, 0, NULL, NULL, NULL, NULL),
(11, 'Stevie Ledner Jr.', 'wyman.nannie@example.com', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'VTcrNoXpWO', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 1, 1, NULL, NULL, NULL, NULL),
(12, 'Dr. Buck White PhD', 'sherman.morissette@example.com', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'uYzjVw1sUr', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 1, 0, NULL, NULL, NULL, NULL),
(13, 'Marcelino Bayer', 'uwiegand@example.com', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'dE5rtOdCsQ', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 1, 1, NULL, NULL, NULL, NULL),
(14, 'Dr. Juwan Glover', 'schmitt.yasmeen@example.org', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'APZj47jm93', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 0, 1, NULL, NULL, NULL, NULL),
(15, 'Russell Rippin', 'rogers93@example.net', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ZbansX4ESR', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 1, 1, NULL, NULL, NULL, NULL),
(16, 'Mafalda Keeling', 'christ97@example.com', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'zHxuszOIQ4', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 0, 0, NULL, NULL, NULL, NULL),
(17, 'Rosalyn Erdman', 'eloise.ondricka@example.com', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'U2u6l2b5m8', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 1, 1, NULL, NULL, NULL, NULL),
(18, 'Mrs. Melisa Hammes DVM', 'christ.dooley@example.com', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'rqFY7xJx1Q', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 0, 0, NULL, NULL, NULL, NULL),
(19, 'Gordon Walter', 'ecrooks@example.org', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '8yod4Zvz7h', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 0, 0, NULL, NULL, NULL, NULL),
(20, 'Muriel Bergnaum', 'qzulauf@example.com', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '8Ru07oZzsn', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 0, 0, NULL, NULL, NULL, NULL),
(21, 'Prof. Christop Johnston II', 'olen.hill@example.org', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'c17VZAgfjG', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 0, 1, NULL, NULL, NULL, NULL),
(22, 'Irma Conroy', 'schneider.fern@example.net', '2021-08-20 07:34:41', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ompmBNZx56', '2021-08-20 07:34:41', '2021-08-20 07:34:41', 1, 1, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_authors`
--
ALTER TABLE `tbl_authors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tbl_authors_slug_unique` (`slug`),
  ADD KEY `tbl_authors_first_name_index` (`first_name`),
  ADD KEY `tbl_authors_last_name_index` (`last_name`),
  ADD KEY `tbl_authors_status_index` (`status`);

--
-- Indexes for table `tbl_books`
--
ALTER TABLE `tbl_books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tbl_books_slug_unique` (`slug`),
  ADD KEY `tbl_books_author_id_index` (`author_id`),
  ADD KEY `tbl_books_title_index` (`title`),
  ADD KEY `tbl_books_status_index` (`status`);

--
-- Indexes for table `tbl_failed_jobs`
--
ALTER TABLE `tbl_failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tbl_failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `tbl_migrations`
--
ALTER TABLE `tbl_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_oauth_access_tokens`
--
ALTER TABLE `tbl_oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tbl_oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `tbl_oauth_auth_codes`
--
ALTER TABLE `tbl_oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tbl_oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indexes for table `tbl_oauth_clients`
--
ALTER TABLE `tbl_oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tbl_oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `tbl_oauth_personal_access_clients`
--
ALTER TABLE `tbl_oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_oauth_refresh_tokens`
--
ALTER TABLE `tbl_oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tbl_oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `tbl_password_resets`
--
ALTER TABLE `tbl_password_resets`
  ADD KEY `tbl_password_resets_email_index` (`email`);

--
-- Indexes for table `tbl_personal_access_tokens`
--
ALTER TABLE `tbl_personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tbl_personal_access_tokens_token_unique` (`token`),
  ADD KEY `tbl_personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tbl_users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_authors`
--
ALTER TABLE `tbl_authors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tbl_books`
--
ALTER TABLE `tbl_books`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `tbl_failed_jobs`
--
ALTER TABLE `tbl_failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_migrations`
--
ALTER TABLE `tbl_migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_oauth_clients`
--
ALTER TABLE `tbl_oauth_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_oauth_personal_access_clients`
--
ALTER TABLE `tbl_oauth_personal_access_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_personal_access_tokens`
--
ALTER TABLE `tbl_personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_books`
--
ALTER TABLE `tbl_books`
  ADD CONSTRAINT `tbl_books_author_id_foreign` FOREIGN KEY (`author_id`) REFERENCES `tbl_authors` (`id`) ON DELETE CASCADE;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
